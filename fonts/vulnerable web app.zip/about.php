<?php
include("template/header.php");
echoHeader("About");
?>
    <div class="col-sm-9 top-margin-2">
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="./">Home</a></li>
  <li class="breadcrumb-item active">About</li>

</ol>

      <h2>About</h2>
      <hr>
      <p>vulnerable webapp helps you to test your skills in penetration testing or learn penetration testing and help developers better understand the processes of securing web applications . This application has been created for beginner users and teachers to teach/learn web application security. feel free to edit/add some codes to this application.</p>
      <div class="alert alert-warning">Do not upload it to your hosting providers public html folder or any internet facing web server as it will be compromised. We recommend downloading and installing <a href="https://www.apachefriends.org/index.html">XAMPP</a> or <a href="http://www.wampserver.com/en/">WAMP</a> onto a local machine inside your LAN which is used solely for testing.</div>
      <p><b>Thanks to : </b>C0d3!Nj3ct!0n , REX , DeMon , <b>Poisoncode</b> , Alizombie , virtual_hate , proxy and all GuardIran security team members</p>
      <p>Design & Developed by Milad Ahmadi</p>
      <p><b>Version 2.0.0</b></p>
      <hr>
      <a href="http://miladahmadi.net">Website</a><br>
      <a href="http://t.me/Ph4en1x">Telegram</a><br>
      <a href="https://github.com/milad00ahmadi">Github</a><br>
      <a href="http://guardiran.org">GuardIran Security Team Website</a><br>

      <!--<h4><small>Learn more</small></h4>-->
      <hr>
    </div>
  </div>
</div>

<?php
include("template/footer.php");
echoFooter();
?>

</body>
</html>
