<?php
function echoFooter(){
	echo '
<footer class="container-fluid footer">
  <p style="margin-top:1vh;display: inline-block;">Design & Developed by <a href="http://miladahmadi.net">Milad Ahmadi</a></p>
</footer>

</body>
</html>
';
}
?>